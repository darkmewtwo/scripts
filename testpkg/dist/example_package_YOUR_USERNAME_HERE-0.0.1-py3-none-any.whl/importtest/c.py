def g():
    print(34)