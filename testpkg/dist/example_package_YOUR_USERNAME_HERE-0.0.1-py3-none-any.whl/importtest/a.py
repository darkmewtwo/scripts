
# from toimport import f, b
# from testpkg import b
# from testpkg import f
# from c import g
# import importtest
# print(test.f(4))
import sys

# sys.path.insert(1, '/home/user/scripts/testpkg')
# print(sys.path)
from toimport import f, b
# print(g())
print(f(3))