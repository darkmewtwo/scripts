def f(r):
   print(r*3)
